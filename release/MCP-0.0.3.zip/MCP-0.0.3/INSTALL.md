# AutoCAD 2024 MCP 0.0.3

## 安装

1. 正常保存并关闭所有 AutoCAD 窗口。
2. 将 `AutoCAD2024Mcp.bundle` 整个目录复制到 `%APPDATA%\Autodesk\ApplicationPlugins\`。
3. 安装 MCP 服务：

   ```powershell
   npm install -g .\autocad-2024-mcp-0.0.3.tgz
   codex mcp add autocad-2024-003 -- autocad-2024-mcp
   ```

4. 重启 AutoCAD 2024 和 Codex；在 AutoCAD 执行 `CADMCPSTATUS`。
5. 多开 AutoCAD 时，先调用 `cad_instances`，再用 `cad_connect` 绑定目标 PID。

## 安全提示

不要从 `D:\CAD\plugin` 手动 `NETLOAD` 开发 DLL。正式插件通过 Autodesk `ApplicationPlugins` Bundle 自动加载，可避免“未签名文件不在受信任文件夹”提示，同时保留 AutoCAD 的安全检查。

`FixShaftExportStl.dll` 等临时插件不属于本发布包。请改用 `cad_export` 的 `stl` 格式和明确的 `selection` 实体句柄。

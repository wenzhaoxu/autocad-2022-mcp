# AutoCAD 2024 MCP 0.1.1

## 安装

1. 关闭全部 AutoCAD 2024 窗口。
2. 将 `AutoCAD2024Mcp.bundle` 复制到 `%APPDATA%\Autodesk\ApplicationPlugins\`。
3. 安装 Node MCP 包：

   ```powershell
   npm install -g .\autocad-2024-mcp-0.1.1.tgz
   ```

4. 启动 AutoCAD 2024，执行 `CADMCPSTATUS`，确认显示版本 0.1.1。
5. 在 MCP 客户端注册命令 `autocad-2024-mcp`，然后重启客户端。

## 验证

执行 `CADMCPSELFTEST`，再调用 `cad_status`。如需验证电气模块，读取 `cad://symbols/electrical/catalog`，调用 `cad_electrical_symbol` 或 `cad_electrical_sheet`，最后通过 `cad_inspect` 检查结果。

旧版本 DLL 已被 AutoCAD 加载时不能原位覆盖。必须关闭 AutoCAD 后再替换 Bundle。
